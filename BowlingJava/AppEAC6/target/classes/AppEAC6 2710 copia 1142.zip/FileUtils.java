

import java.io.File;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Set;

public class FileUtils {
    String dataDirectory;
 
public void inicialitzeWorkDirectory(){
        //Default working directory
        dataDirectory = System.getProperty("user.dir")+ File.separator + "dades";
        //Check if the working directory exists
        File fDir;
        fDir = new File(dataDirectory);
        if (!fDir.exists()){
            //If it doesn't exist, create it.
            fDir.mkdir();
        }
    } 
public String getDirectoryDades(){
        return dataDirectory;
    }
public void mostrarDirectori(){
        //Display the top-level tree of the current directory (no subdirectories)
        File carpeta = new File(dataDirectory);
        File[] arrayElements = carpeta.listFiles();
        
        System.out.println(Constants.DIRECTORY_CONTENT + carpeta.getAbsolutePath() + " és: ");
        
        //We iterate through the array and display the tree
        for (int i=0; i<arrayElements.length;i++){
            File f =arrayElements[i];
            if (f.isDirectory()){
                System.out.print("[DIR] ");
            }else{
                System.out.print("[FIT] ");
            }
            System.out.println(f.getName());
        }
    }
public boolean esborrarFitxer(String Filename){
        //Esborra el fitxer que rep per paràmetre. El fitxer ha d'existir a la carpeta de dades
        /* if (Filename.isEmpty()){
            return false;  //Retorna False en la resta de casos
        }
        File file = new File(directoriDades + File.separator + nomFitxer);
        return file.delete(); //Retorna True si s'ha pogut esborrar*/
        File fFile;
        
        if(FileExists(Filename)){
            fFile = new File(Filename);
            return fFile.delete();
        }
        
        return false;
    } 
public boolean FileExists(String Filename){
        //Mirem si existeix el fitxer i si aquest té un tamany més gran de 0.
        if (Filename.isEmpty()){
            return false;  //Retorna False en la resta de casos
        }
        File f = new File(dataDirectory.concat(File.separator).concat(Filename));
        //File f = new File(Filename);
        return f.exists() && f.length()>0;
    }
public void saveDataToFile(String[][] playersData, int[][] pointsMatrix) {
    String dadesFile = dataDirectory + File.separator + Constants.DATA_FILE;
  
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(dadesFile, true))){
        

        // Iniciem el BufferedWriter
       // BufferedWriter bw = new BufferedWriter(new FileWriter(dadesFile, true));

        // Afegim la data i hora actual al fitxer
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmm");
        
        // Si alguna de les matrius és null, tornem
        if (playersData == null || pointsMatrix == null) {
            return;
        }
        // Si el nombre de files a les matrius és diferent, tornem
        if (playersData.length != pointsMatrix.length) {
            return;
        }
        // Si el nombre de files és 0, tornem
        if (playersData.length == 0 || pointsMatrix.length == 0) {
            return;
        }

        StringBuilder acumulador = new StringBuilder();

        for (int i = 0; i < playersData.length; i++) {
            // Afegim el nom i cognom del jugador
             acumulador.append(now.format(formatter)).append(",")
                       .append(playersData[i][0]).append(",") // Nom
                       .append(playersData[i][1]).append(",") // Cognom
                       .append(playersData[i][2]).append(",");//Edat
             
           
            // Afegim els punts a l'acumulador
            for (int j = 0; j < pointsMatrix[i].length; j++) {
                acumulador.append(pointsMatrix[i][j]).append(j < pointsMatrix[i].length - 1 ? "," : "");
            }
            // Afegim una nova línia després de cada jugador
            acumulador.append("\n");
        }

        // Escrivim les dades acumulades al fitxer
        bw.write(acumulador.toString());

        // Tancament del BufferedWriter
        bw.close();

    } catch (IOException e) {
        e.printStackTrace();
    }
    
}
//Llista el primer camp del fitxer
public void listUniqueFirstField(String filePath){
    
    Set<String> uniqueIdentifiers = new HashSet<>(); // Utilitzem un conjunt per evitar duplicats

        try (BufferedReader br = new BufferedReader(new FileReader(filePath + File.separator + Constants.DATA_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(","); // Separem per comes
                if (parts.length > 0) {
                    uniqueIdentifiers.add(parts[0]); // Afegim el primer camp al conjunt
                }
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Imprimim els identificadors únics
        System.out.println("Identificadors únics:");
        for (String id : uniqueIdentifiers) {
            System.out.println(id);
        }
    //Retornem el nombre de identificadors únics.
    //return uniqueIdentifiers.size();
}
//Conta a partir del codi, quantes files hi ha al fitxer amb el mateix codi per dimensionar la mat
public int countRowsWithCode(String lineCode) {
    String dataFile = dataDirectory + File.separator + Constants.DATA_FILE;
    int count = 0;

    try (BufferedReader br = new BufferedReader(new FileReader(dataFile))) {
        String line;

        while ((line = br.readLine()) != null) {
            // Suposem que les dades estan separades per comes
            String[] parts = line.split(",");

            // Comprovem que hi ha suficients parts i que el codi és el primer element
            if (parts.length > 0 && parts[0].equals(lineCode)) {
                count++;
            }
        }

    } catch (IOException e) {
        e.printStackTrace();
    }

    return count;
}
//Carrega registres des del fitxer a les matrius
public void loadDataFromFile(long dataNumber, String[][] playersData, int[][] pointsMatrix) {
    String dadesFile = dataDirectory + File.separator + Constants.DATA_FILE;

    try (BufferedReader br = new BufferedReader(new FileReader(dadesFile))) {
        String line;
        int playerIndex = 0;

        while ((line = br.readLine()) != null) {
            // Dividim cada línia en funció de la coma
            String[] parts = line.split(",");

            // Comprovem que la línia compleixi el format esperat i coincideixi amb el número de data especificat
            if (parts.length < 4 || !parts[0].equals(String.valueOf(dataNumber))) {
                continue;
            }

            // Verifiquem que hi hagi espai suficient a playersData i pointsMatrix per evitar desbordaments
            if (playerIndex >= playersData.length || playerIndex >= pointsMatrix.length) {
                System.out.println("Error: Les matrius no tenen suficient espai per emmagatzemar totes les dades.");
                break;
            }

            // Guardem nom, cognom i edat a playersData
            playersData[playerIndex][0] = parts[1]; // Nom
            playersData[playerIndex][1] = parts[2]; // Cognom
            playersData[playerIndex][2] = parts[3]; // Edat

            // Guardem els punts a pointsMatrix, amb comprovació de límits
            for (int j = 0; j < pointsMatrix[playerIndex].length && (j + 4) < parts.length; j++) {
                pointsMatrix[playerIndex][j] = Integer.parseInt(parts[j + 4]);
            }

            playerIndex++;
        }

    } catch (IOException | NumberFormatException e) {
        e.printStackTrace();
    }
}

    /**
     *
     * @param futils
     * @param dateInput
     */
    public void deletePartialFile(FileUtils futils, String dateInput) {
    try {
        String dataFile = futils.getDirectoryDades() + File.separator + Constants.DATA_FILE;
        File originalFile = new File(dataFile);
        File tempFile = new File(dataFile + "_temp");

        try (BufferedReader br = new BufferedReader(new FileReader(originalFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            boolean delete = true; // Marca per determinar si eliminem o guardem
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                
                // Si el primer camp és la data especificada, deixem de suprimir
                if (parts.length > 0 && parts[0].equals(dateInput)) {
                    delete = false;
                }

                // Si la marca delete és falsa, guardem les línies restants al fitxer temporal
                if (!delete) {
                    bw.write(line);
                    bw.newLine();
                }
            }
        }

        if (originalFile.delete() && tempFile.renameTo(originalFile)) {
            System.out.println("Els registres anteriors a " + dateInput + " han estat eliminats correctament.");
        } else {
            System.out.println("No s'ha pogut actualitzar el fitxer.");
        }       
    } catch (IOException e) {
        System.out.println("S'ha produït un error: " + e.getMessage());
    }
}

}//Fi FileUtils
    


        
        


        
    
