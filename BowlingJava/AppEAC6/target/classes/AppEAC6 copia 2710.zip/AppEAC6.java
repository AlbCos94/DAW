

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
/**
 *
 * @author IOC - 2024-2025 - S1 - UF3
 */

import java.io.File;
import java.util.Scanner;

public class AppEAC6 {

    public static void main(String[] args) {
        AppEAC6 bowlingApp = new AppEAC6();
        bowlingApp.start();
    }

    public void start() {
        //FileUtils object instantiation and initialize working directory
        FileUtils futils = new FileUtils();
        futils.inicialitzeWorkDirectory();

        // ask for the number of players
        int playersNumber = UtilsIO.askForInteger(Constants.MESSAGE_ASK_PLAYERS_NUMBER, Constants.MESSAGE_ERROR_NO_INTEGER);
        // if the number of players is less than 1, we return
        if (playersNumber < 1) {
            UtilsIO.showError(Constants.MESSAGE_ERROR_INCORRECT_PLAYER_NUMBER);
            return;
        }
        // initialize the players data and the points matrix
        BowlingData bowlingData = new BowlingData();
        bowlingData.initializePlayers(playersNumber);
        bowlingData.initializePoints(playersNumber);
        // ask the user for the player names
        for (int i = 0; i < bowlingData.playersData.length; i++) {
            var name = UtilsIO.askForString(i + 1 + "/" + bowlingData.playersData.length + " - " + Constants.MESSAGE_INSERT_NAME, Constants.MESSAGE_ERROR_EMPTY_STRING);
            var lastName = UtilsIO.askForString(i + 1 + "/" + bowlingData.playersData.length + " - " + Constants.MESSAGE_INSERT_LAST_NAME, Constants.MESSAGE_ERROR_EMPTY_STRING);
            var age = UtilsIO.askForInteger(i + 1 + "/" + bowlingData.playersData.length + " - " + Constants.MESSAGE_INSERT_AGE, Constants.MESSAGE_ERROR_NO_INTEGER);
            UtilsBowling.insertPlayerNames(bowlingData.playersData, i, name, lastName, age);
        }
        // show the menu. Don't exit until the user wants to
        boolean exitLoop = false;
        while (!exitLoop) {
            UtilsIO.showMenu(Constants.START_MENU);
            int option = UtilsIO.askForInteger(Constants.MESSAGE_ASK_INTEGER_VALUE, Constants.MESSAGE_ERROR_NO_INTEGER);
            switch (option) {
                case 1: {
                    // set the points for a round
                    askForRoundPoints(bowlingData.playersData, bowlingData.pointsMatrix);
                    UtilsIO.showRounds(bowlingData.playersData, bowlingData.pointsMatrix);
                    break;
                }
                case 2: {
                    // show the totals
                    showTotalPoints(bowlingData.playersData, bowlingData.pointsMatrix);
                    break;
                }
                case 3: {
                    // correct the points for a round
                    correctPlayerPoints(bowlingData.playersData, bowlingData.pointsMatrix);
                    break;
                }
                case 4:{
                    filesMenu(futils, bowlingData);
                    break;
                }
                case 0: {
                    //save the data to the file databowling.txt.
                    futils.saveDataToFile(bowlingData.playersData, bowlingData.pointsMatrix);
                    // exit the program
                    exitLoop = true;
                    break;
                }
                default: {
                    // show an error message if the option is not valid
                    UtilsIO.showError(Constants.MESSAGE_NOT_VALID_OPTION);
                    break;
                }
            }
        }
    }
    
     private void filesMenu(FileUtils futils, BowlingData bowlingData) {
        boolean exitLoop = false;
        while (!exitLoop) {
            UtilsIO.showMenu(Constants.START_MENU_FILE);
            int option = UtilsIO.askForInteger(Constants.MESSAGE_ASK_INTEGER_VALUE, Constants.MESSAGE_ERROR_NO_INTEGER);
            switch (option) {
                case 1: {
                    //Display path of the dadesBowling.txt directory
                    OptionShowPath(futils);
                    //UtilsIO.afegirEntradaLog(UtilsES.LOG_DIRECTORI, futils);
                    break;
                }
                case 2: {
                    // We check if the file dataBowling.txt exists
                    optionCheckFiles(futils);
                    break;
                }
                case 3: {
                    // Display working directory
                    futils.mostrarDirectori();
                    break;
                }
                case 4:{
                    //Carreguem una ronda del fitxer dadesBowling
                    //Primer mostrem les dates sense repeticions
                    recoverGame(futils, bowlingData);
                    break;
                }
                case 5: //Esborrar fitxer fins una data
                    deletePartialFile(futils);
                case 0: {
                    // exit the program
                    System.out.println(Constants.RETURN_MESSAGE);
                    
                    exitLoop = true;
                    break;
                }
                default: {
                    // show an error message if the option is not valid
                    UtilsIO.showError(Constants.MESSAGE_NOT_VALID_OPTION);
                    break;
                }
            }
        }  
    }
     
    //UF3
    public void OptionShowPath(FileUtils futils){
        System.out.println(Constants.DIRECTORY_MESSAGE_IO);
        System.out.println(futils.getDirectoryDades());
    }
    
    public void optionCheckFiles(FileUtils futils){
        
        if(futils.FileExists(Constants.DATA_FILE) == true){
            System.err.println(Constants.MESSAGE_FILE_EXISTS);
                }else{
            System.err.println(Constants.MESSAGE_FILE_DOES_NOT_EXIST);
        }
    }
     

    public void recoverGame(FileUtils futils, BowlingData bowlingData){

        //Demanem a l'usuari si vol guardar les dades actuals o sobreescriure-les
        //String dataFile = futils.getDirectoryDades()+ File.separator + Constants.DATA_FILE; 
        //String dataFile = futils.getDirectoryDades()+ File.separator + Constants.DATA_FILE; 
        if(futils.FileExists(Constants.DATA_FILE)){
                Scanner scanner = new Scanner(System.in);
                System.out.println(Constants.RECOVERY_GAME);
                String userInput = scanner.nextLine().trim().toLowerCase();

                switch (userInput) {
                   case "g":                                      ////????????ARRRRECCCLAR-HO AMB METODES I CONSTANTS
                       // Case to save the current data and load from historic
                       saveCurrentData(futils, bowlingData); // Call methode save data

                       //Carreguem una ronda del fitxer històric dadesBowling
                       loadDataFromFile(futils, bowlingData);

                       break;
                   case "s":
                       // Case to load directly without saving
                       loadDataFromFile(futils, bowlingData); // Call your load method here
                       break;
                   default:
                       System.out.println(Constants.RETURN_MESSAGE);
                       break;
                }
            
        }    
         else System.out.println ("No hi ha dades per carregar.");
    
        
    }
    
    private void saveCurrentData(FileUtils futils, BowlingData bowlingData) {
        //save the data to the file databowling.txt.
        futils.saveDataToFile(bowlingData.playersData, bowlingData.pointsMatrix);
}

    private void loadDataFromFile(FileUtils futils, BowlingData bowlingData) {
        //Carreguem una ronda del fitxer històric dadesBowling
            //Primer mostrem les dates sense repeticions
            futils.listUniqueFirstField(futils.getDirectoryDades());
         
            long numero;
            Scanner scanner = new Scanner(System.in);
            System.out.print("Introdueix el codi numèric de recuperació: ");
            while (!scanner.hasNextLong()) {  // Verifica si l'entrada és un enter
                System.out.println("Això no és un número enter. Introdueix un número enter: ");
                scanner.next();  // Neteja l'entrada no vàlida
            }
            numero = scanner.nextLong();  // Llegeix l'enter vàlid
            System.out.println("El numero escollit es: " + numero);
            //Conta número de linies que hi ha iguals
            String number = Long.toString(numero);
            
            int numberLines = futils.countRowsWithCode(number);
            //Redimensionem matriu perquè capiguen tots els registres.
            bowlingData.initializePlayers(numberLines);
            bowlingData.initializePoints(numberLines);
            //Cridem el mètode de càrrega de fitxer amb la dada que ens ha donat l'usuari.
            futils.loadDataFromFile(numero, bowlingData.playersData, bowlingData.pointsMatrix);
            System.out.println("Game data loaded successfully.");
        
    }
    
    private void deletePartialFile(FileUtils futils){
        
        // Llistar les dates úniques del primer camp
        String dataFile = futils.getDirectoryDades(); 
        if( futils.FileExists(Constants.DATA_FILE)){
            futils.listUniqueFirstField(dataFile);
            // Demanar a l'usuari que introdueixi una data específica del llistat
            Scanner scanner = new Scanner(System.in);
            System.out.println("Introdueix una de les dates del llistat per eliminar els registres anteriors a la data especificada: ");
            String dateInput = scanner.nextLine();

            // Cridar el fitxer que les elimina
            futils.deletePartialFile(futils, dateInput);
            
        }
        else System.out.println("No hi ha elements per recuperar. El fitxer és buit.");
        
  
    }
    //Fi UF3

    private void showTotalPoints(String[][] playersData, int[][] pointsMatrix) {
       // calculate the total points for each player
        int[] totalPoints = UtilsBowling.calculateTotalPointsArray(pointsMatrix);
        // calculate the index array with the order of the players
        int[] indexArray = UtilsBowling.getOrderedIndexArrayWithTotalPoints(totalPoints);
        // show the ordered list
        UtilsIO.showOrderedPointsList(playersData, totalPoints, indexArray);
    }

    private void correctPlayerPoints(String[][] playersData, int[][] pointsMatrix) {
        // ask the user for the player to correct
        String playerName = UtilsIO.askForString(Constants.MESSAGE_INSERT_FULL_NAME, Constants.MESSAGE_ERROR_EMPTY_STRING);
        int playerIndex = UtilsBowling.lookForPlayer(playersData, playerName);
        // if the player is not found, we return
        if (playerIndex == -1) {
            UtilsIO.showError(Constants.MESSAGE_ERROR_PLAYER_NOT_FOUND);
            return;
        }
        // ask for the round to correct
        int round = UtilsIO.askForInteger(Constants.MESSAGE_INSERT_ROUND, Constants.MESSAGE_ERROR_NO_INTEGER);
        // it the round is not valid, we return
        if (round < 1 || round > Constants.THROWS_NUMBER) {
            UtilsIO.showError(Constants.MESSAGE_ERROR_NO_VALID_ROUND);
            return;
        }
        // ask for the points for the round
        int playerPoints = UtilsIO.askForInteger(Constants.MESSAGE_INSERT_POINTS + playersData[playerIndex][Constants.INDEX_NAME] + " " + playersData[playerIndex][Constants.INDEX_LAST_NAME], Constants.MESSAGE_ERROR_NO_INTEGER);
        // if the points are not valid, we return
        if (playerPoints < 0 || playerPoints > Constants.MAX_POINTS) {
            UtilsIO.showError(Constants.MESSAGE_ERROR_NO_VALID_POINTS);
            return;
        }
        // set the points in the matrix
        UtilsBowling.setRoundPoints(pointsMatrix, playerIndex, round, playerPoints);
        UtilsIO.showRounds(playersData, pointsMatrix);
    }

    private void askForRoundPoints(String[][] playersData, int[][] pointsMatrix) {
        // ask for the round to set the points
        int round = UtilsIO.askForInteger(Constants.MESSAGE_INSERT_ROUND, Constants.MESSAGE_ERROR_NO_INTEGER);
        // it the round is not valid, we return
        if (round < 1 || round > Constants.THROWS_NUMBER) {
            UtilsIO.showError(Constants.MESSAGE_ERROR_NO_VALID_ROUND);
            return;
        }
        // ask for the points for each player
        for (int i = 0; i < playersData.length; i++) {
            int playerPoints = UtilsIO.askForInteger(Constants.MESSAGE_INSERT_POINTS + playersData[i][Constants.INDEX_NAME] + " " + playersData[i][Constants.INDEX_LAST_NAME], Constants.MESSAGE_ERROR_NO_INTEGER);
            while (playerPoints < 0 || playerPoints > Constants.MAX_POINTS) {
                UtilsIO.showError(Constants.MESSAGE_ERROR_NO_VALID_POINTS);
                playerPoints = UtilsIO.askForInteger(Constants.MESSAGE_INSERT_POINTS + playersData[i][Constants.INDEX_NAME] + " " + playersData[i][Constants.INDEX_LAST_NAME], Constants.MESSAGE_ERROR_NO_INTEGER);
            }
            UtilsBowling.setRoundPoints(pointsMatrix, i, round, playerPoints);
        }
    }

   


}